"""Transport boundary: input_reply only, no input files or recorded history."""
import json
import uuid

class TransportError(ConnectionError):
    pass

class MemoryBackend:
    def __init__(self,transport):self.transport=transport
    def predict(self,candidate,blocks,page,timeout_s):
        return self.transport(dict(action='predict',candidate_id=candidate,blocks=blocks,page=page,
                                   timeout_s=timeout_s,persist_input=False))

class ColabStdinTransport:
    def __init__(self,session,remote_code='/content/order-code',environment='/content/order-config-20261102'):
        from colab_cli.state import StateStore
        from colab_cli.runtime import ColabRuntime
        state=StateStore().get(session)
        if state is None or state.accelerator!='A100':raise ValueError('An existing A100 session is required')
        self._runtime_factory=lambda:ColabRuntime(state.url,state.token,session_name=None,history=None,
                                                 kernel_id=state.kernel_id,session_id=state.session_id)
        self.runtime=None
        self.remote_code,self.environment=remote_code,environment
        self._failed=False

    def __call__(self,request):
        if request.get('persist_input') is not False:raise ValueError('Only nonpersistent input requests are accepted')
        if getattr(self,'_failed',False):raise TransportError('Transport unavailable; no input resubmitted')
        if self.runtime is None:self.runtime=self._runtime_factory()
        request_id=uuid.uuid4().hex
        payload=json.dumps(dict(request,request_id=request_id),allow_nan=False)
        code="""
import json,sys
sys.path.insert(0,REMOTE_CODE)
from reading_order.memory_bridge import KernelBridge
if '_order_bridge' not in globals():
    _order_bridge=KernelBridge(REMOTE_CODE,ENVIRONMENT)
_order_request=json.loads(input('ORDER_MEMORY_INPUT'))
try:
    print('ORDER_RESULT:'+json.dumps(_order_bridge.handle(_order_request),allow_nan=False),flush=True)
finally:
    del _order_request
""".replace('REMOTE_CODE',repr(self.remote_code)).replace('ENVIRONMENT',repr(self.environment))
        def reply_to_input(_):self.runtime.kernel_client._manager.client.input(payload)
        try:
            outputs=self.runtime.execute_code(code,allow_stdin=True,stdin_hook=reply_to_input,
                                              timeout=request.get('timeout_s',300)+30)
            result=None
            for output in outputs:
                if output.get('output_type')=='error':raise RuntimeError('Remote bridge error')
                for line in output.get('text','').splitlines():
                    if line.startswith('ORDER_RESULT:'):
                        envelope=json.loads(line[len('ORDER_RESULT:'):])
                        if envelope['request_id']!=request_id:raise ValueError('Mismatched response identity')
                        result=envelope['response']
            if result is None:raise RuntimeError('No confirmed worker result')
            return result
        except Exception:
            self._failed=True
            raise TransportError('Transport unavailable; no input resubmitted') from None
        finally:
            # Each request owns a socket, but never the kernel or model worker.
            runtime,self.runtime=self.runtime,None
            if runtime is not None and hasattr(runtime,'stop'):runtime.stop()

    def close(self):
        runtime=self.runtime or self._runtime_factory()
        try:
            runtime.execute_code("if '_order_bridge' in globals():\n _order_bridge.close()\n",timeout=20)
        finally:
            runtime.stop();self.runtime=None

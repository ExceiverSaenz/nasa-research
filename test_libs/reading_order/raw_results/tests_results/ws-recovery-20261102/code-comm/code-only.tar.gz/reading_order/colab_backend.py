"""Authenticated comm payloads stay in memory, outside code/history/files."""
import json
import uuid

class TransportError(ConnectionError):
    pass

class MemoryBackend:
    def __init__(self,transport):self.transport=transport
    def predict(self,candidate,blocks,page,timeout_s):
        return self.transport(dict(action='predict',candidate_id=candidate,blocks=blocks,page=page,
                                   timeout_s=timeout_s,persist_input=False))

class ColabStdinTransport:
    def __init__(self,session,remote_code='/content/order-code',environment='/content/order-config-20261102'):
        from colab_cli.state import StateStore
        from colab_cli.runtime import ColabRuntime
        state=StateStore().get(session)
        if state is None or state.accelerator!='A100':raise ValueError('An existing A100 session is required')
        self._runtime_factory=lambda:ColabRuntime(state.url,state.token,session_name=None,history=None,
                                                 kernel_id=state.kernel_id,session_id=state.session_id)
        self.runtime=None
        self.remote_code,self.environment=remote_code,environment
        self._failed=False

    def __call__(self,request):
        if request.get('persist_input') is not False:raise ValueError('Only nonpersistent input requests are accepted')
        if getattr(self,'_failed',False):raise TransportError('Transport unavailable; no input resubmitted')
        if self.runtime is None:self.runtime=self._runtime_factory()
        request_id=uuid.uuid4().hex
        payload=dict(request,request_id=request_id)
        json.dumps(payload,allow_nan=False)
        code="""
import json,sys
sys.path.insert(0,REMOTE_CODE)
from reading_order.memory_bridge import KernelBridge
if '_order_bridge' not in globals():
    _order_bridge=KernelBridge(REMOTE_CODE,ENVIRONMENT)
_order_request=_order_pending.pop(REQUEST_ID)
try:
    print('ORDER_RESULT:'+json.dumps(_order_bridge.handle(_order_request),allow_nan=False),flush=True)
finally:
    del _order_request
""".replace('REMOTE_CODE',repr(self.remote_code)).replace('ENVIRONMENT',repr(self.environment)).replace('REQUEST_ID',repr(request_id))
        try:
            if not getattr(self,'_comm_ready',False):
                setup="""
if '_order_pending' not in globals():_order_pending={}
def _order_receive(comm,msg):
    _order_pending[comm.comm_id]=msg['content']['data']
    comm.close()
get_ipython().kernel.comm_manager.register_target('reading_order_memory',_order_receive)
print('ORDER_COMM_READY',flush=True)
"""
                ready=self.runtime.execute_code(setup,allow_stdin=False,timeout=30)
                if not any('ORDER_COMM_READY' in o.get('text','') for o in ready):raise RuntimeError('Comm setup not confirmed')
                self._comm_ready=True
            client=self.runtime.kernel_client._manager.client
            client.shell_channel.send(client.session.msg('comm_open',content=dict(
                comm_id=request_id,target_name='reading_order_memory',data=payload)))
            outputs=self.runtime.execute_code(code,allow_stdin=False,timeout=request.get('timeout_s',300)+30)
            result=None
            for output in outputs:
                if output.get('output_type')=='error':raise RuntimeError('Remote bridge error')
            for line in ''.join(output.get('text','') for output in outputs).splitlines():
                if line.startswith('ORDER_RESULT:'):
                    envelope=json.loads(line[len('ORDER_RESULT:'):])
                    if envelope['request_id']!=request_id:raise ValueError('Mismatched response identity')
                    result=envelope['response']
            if result is None:raise RuntimeError('No confirmed worker result')
            return result
        except Exception:
            self._failed=True
            self._disconnect()
            raise TransportError('Transport unavailable; no input resubmitted') from None

    def _disconnect(self):
        runtime,self.runtime=self.runtime,None
        if runtime is None:return
        # Wake the installed websocket client's blocking reader before its
        # stop_channels clears the socket reference. Never shut down the kernel.
        kernel=getattr(runtime,'_kernel_client',None)
        client=getattr(getattr(kernel,'_manager',None),'client',None)
        app=getattr(client,'kernel_socket',None)
        thread=getattr(client,'connection_thread',None)
        if app is not None:
            app.keep_running=False
            socket=getattr(app,'sock',None)
            if socket is not None:
                try:socket.abort()
                except OSError:pass
            if thread is not None:thread.join(timeout=5)
        if hasattr(runtime,'stop'):runtime.stop()

    def close(self):
        runtime=self.runtime or self._runtime_factory()
        try:
            runtime.execute_code("if '_order_bridge' in globals():\n _order_bridge.close()\n",timeout=20)
        finally:
            self.runtime=runtime
            self._disconnect()

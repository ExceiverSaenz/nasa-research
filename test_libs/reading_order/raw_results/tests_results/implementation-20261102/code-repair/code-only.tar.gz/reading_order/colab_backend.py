"""Transport boundary: only in-memory request bodies, never input files."""
import json

class MemoryBackend:
    def __init__(self, transport):
        self.transport = transport

    def predict(self, candidate, blocks, page, timeout_s):
        return self.transport(dict(action='predict',candidate_id=candidate,blocks=blocks,page=page,
                                   timeout_s=timeout_s,persist_input=False))


class ColabStdinTransport:
    """Use the installed CLI runtime's authenticated stdin channel without history.

    Code cells contain only this static bridge. Source payloads and signed R2
    requests travel as input_reply messages, never code literals, files or logs.
    """
    def __init__(self, session, remote_code='/content/order-code', environment='/content/order-config-20261102'):
        from colab_cli.state import StateStore
        from colab_cli.runtime import ColabRuntime
        state = StateStore().get(session)
        if state is None or state.accelerator != 'A100':
            raise ValueError('An existing A100 session is required')
        self.runtime = ColabRuntime(state.url,state.token,session_name=None,history=None,
                                    kernel_id=state.kernel_id,session_id=state.session_id)
        self.remote_code, self.environment = remote_code, environment

    def __call__(self, request):
        if request.get('persist_input') is not False:
            raise ValueError('Only nonpersistent input requests are accepted')
        code = r"""
import json,subprocess,os,select,time
_order_request=json.loads(input('ORDER_MEMORY_INPUT'))
try:
    _order_candidate=_order_request.get('candidate_id','metadata')
    if '_order_child' in globals() and (_order_child.poll() is not None or _order_active != _order_candidate):
        if _order_child.poll() is None:
            _order_child.terminate()
            _order_child.wait(timeout=10)
        del _order_child
    if '_order_child' not in globals():
        _order_env=dict(os.environ,PYTHONPATH=REMOTE_CODE,HF_HUB_OFFLINE='1',TRANSFORMERS_OFFLINE='1',
                        PYTHONDONTWRITEBYTECODE='1',HF_HUB_DISABLE_PROGRESS_BARS='1')
        _order_child=subprocess.Popen([ENVIRONMENT+'/venv/bin/python','-B','-u','-m','reading_order.worker',
                                       '--environment',ENVIRONMENT],stdin=subprocess.PIPE,stdout=subprocess.PIPE,
                                       stderr=subprocess.DEVNULL,text=True,env=_order_env)
        _order_active=_order_candidate
    _order_child.stdin.write(json.dumps(_order_request)+'\n')
    _order_child.stdin.flush()
    _order_deadline=time.monotonic()+_order_request.get('timeout_s',300)
    while True:
        _order_remaining=_order_deadline-time.monotonic()
        if _order_remaining<=0 or not select.select([_order_child.stdout],[],[],max(0,_order_remaining))[0]:
            _order_child.kill()
            _order_child.wait()
            raise TimeoutError('Memory worker deadline exceeded')
        _order_line=_order_child.stdout.readline()
        if not _order_line:
            raise RuntimeError('Memory worker exited without a result')
        if _order_line.startswith('ORDER_RESULT:'):
            print(_order_line.strip(),flush=True)
            break
finally:
    del _order_request
""".replace('REMOTE_CODE',repr(self.remote_code)).replace('ENVIRONMENT',repr(self.environment))
        payload = json.dumps(request, allow_nan=False)
        # The installed jupyter client hook must send input_reply itself; its
        # return value is ignored. ColabRuntime wraps it only for optional logs.
        def reply_to_input(_):
            self.runtime.kernel_client._manager.client.input(payload)
        outputs = self.runtime.execute_code(code,allow_stdin=True,stdin_hook=reply_to_input,
                                            timeout=request.get('timeout_s',300)+30)
        result = None
        for output in outputs:
            if output.get('output_type') == 'error':
                raise RuntimeError('Remote bridge failed; inspect session without resubmitting input')
            for line in output.get('text','').splitlines():
                if line.startswith('ORDER_RESULT:'):
                    result = json.loads(line[len('ORDER_RESULT:'):])
        if result is None:
            raise RuntimeError('No confirmed worker result')
        return result

    def close(self):
        self.runtime.execute_code("if '_order_child' in globals() and _order_child.poll() is None:\n _order_child.terminate()\n _order_child.wait(timeout=10)\n",timeout=20)
        self.runtime.stop()
